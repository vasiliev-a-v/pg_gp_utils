

func_check_ssh() { # check SSH to hosts from file $all_hosts.
  SSH_TIMEOUT="${SSH_TIMEOUT:-5}"     # ssh connection timeout in sec
  SSH_PORT="${SSH_PORT:-22}"          # SSH port
  SSH_OPTS=(
    -p "$SSH_PORT"
    -o BatchMode=yes
    -o ConnectTimeout="$SSH_TIMEOUT"
    -o ConnectionAttempts=1
    -o StrictHostKeyChecking=no
    -o UserKnownHostsFile=/dev/null
    -o LogLevel=ERROR
  )
  local fail=0

  while IFS= read -r host || [[ -n "$host" ]]; do
    # пропуск пустых строк и комментариев
    [[ -z "$host" || "$host" =~ ^[[:space:]]*# ]] && continue

    if func_run_ssh "$host"; then
      printf 'OK   %s\n' "$host"
    else
      printf 'FAIL %s — нет соединения\n' "$host"
      ((fail++))
    fi
  done < "$all_hosts"
}


func_run_ssh() {
  local host="$1"

  if command -v timeout >/dev/null 2>&1; then
    timeout "$((SSH_TIMEOUT + 3))"s ssh -q "${SSH_OPTS[@]}" "$host" true </dev/null
  else
    ssh -q "${SSH_OPTS[@]}" "$host" true </dev/null
  fi
}


