#!/bin/bash

exit 1 ERROR: No such file, defined in -all-hosts option
exit 2 ERROR: Incorrect -gpseg: $s (expected -1 | N | pN | mN)
exit 3 ERROR: Incorrect format start or end variable
exit 4 ERROR: "start" must be before "end"
exit 5 ERROR: variable $MASTER_DATA_DIRECTORY is empty
exit 6 ERROR: The current user does not match the DBMS system owner user!
exit 7 ERROR: Can not create directory
exit 8 ERROR: Errors occurred while copying log files









