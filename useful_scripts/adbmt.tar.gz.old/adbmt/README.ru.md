Утилита adbmt (Arenadata DB Magic Tool) предоставляет набор инструментов (tool) для сбора диагностической информации, необходимой службе техподдержкой поддержки Arenadata.
Утилита adbmt - это приблизительный аналог утилиты gpmt.

    УСТАНОВКА:
Скопировать на мастер-ноду файл adbmt.tar.gz в директорию /tmp.
Распаковать tar.gz архив с утилитой командами:
```
tar Pxfz /tmp/adbmt.tar.gz -C /tmp
chown -R gpadmin:gpadmin /tmp/adbmt
ls -ld /tmp/adbmt
```

    TOOL:
  gp_log_collector
Это инструмент (tool) для сбора логов и параметров, необходимых для диагностики СУБД.

Инструмент gp_log_collector может быть запущен в одном из трех вариантов:
  1. выгрузка журналов сообщений СУБД с мастера.
  2. выгрузка журналов сообщений СУБД с сегмента: primary или mirror.
  3. сбор диагностической информации.


  1. выгрузка журналов сообщений СУБД с мастера.
При выгрузке журналов сообщений СУБД утилита выгружает соответствующие файлы за установленный параметрами -start и -end период в рабочую директорию на мастер-ноде.
Рабочую директорию можно переопределить параметром -dir.
По умолчанию - это /tmp.
Несжатые csv-файлы утилита при копировании сжимает в gz-архив.
При формировании списка файлов для копирования задействуется "Оценщик".
"Оценщик" производит подсчёт необходимого объёма копирования.
Список файлов для копирования может занимать значительный объём.
В связи с этим был введён параметр -free-space.
С помощью -free-space устанавливается пороговый процент от того раздела, на который будет произведено копирование файлов.
Если объём файлов превышает этот процент, то "Оценщик" сообщает о превышении порога, и копирование не происходит.
По умолчанию порог -free-space установлен в 10%.
После выгрузки лог-файлов на мастер-ноду, утилита adbmt формирует оконечный tar.gz.
Имя оконечного tar.gz файла будет отображено в стандартном выводе и в лог-файле утилиты adbmt.
Например:
/tmp/adbmt_master_gpseg-1.tar.gz
Для сбора журналов сообщений СУБД необходимо указать параметр -gpseg и задать номер -1.
Пример команды:
adbmt.sh gp_log_collector -gpseg -1 -start 2015-11-25_09:00 -end 2015-11-25_18:00


  2. выгрузка журналов сообщений СУБД с сегмента: primary или mirror.
Выгрузка журналов с сегмента происходит аналогично выгрузке с мастера.
Для сбора необходимо указать параметр -gpseg, задать роль сегмента буквой p (primary) или m (mirror) и указать номер сегмента.
Например, команда для mirror-сегмента 2:
adbmt.sh gp_log_collector -gpseg m2 -start 2015-11-25_09:00 -end 2015-11-25_18:00

В самом начале работы утилиты adbmt происходит проверка ssh-соединения с хостами кластера СУБД из списка всех имён хостов кластера ADB.
Полный путь к файлу со списком всех имён хостов кластера ADB задаётся параметром -all-hosts.
Если список не задан, то по умолчанию используется файл:
/home/gpadmin/arenadata_configs/arenadata_all_hosts.hosts
По результатам проверки ssh-соединения создаётся файл хостов, к которым есть доступ по ssh.
Имя файла: available_hosts.hosts.


  3. Сбор диагностической информации состоит из сбора:
    3.1. динамической информации - 1-й снимок.
    3.2. статической информации.
    3.3. информации PXF (опционально).
    3.4. информации из базы gpperfmon (опционально). Может быть собрана, если установлен gpperfmon.
    3.5. информации из схемы adbmon (опционально). Может быть собрана, если установлен adbmon.
    3.6. динамической информации - 2-й снимок.

3.1. Сбор динамической информации состоит из двух снимков.
Динамическая информация имеет смысл для оценки её во времени.
Например, это оценка роста сетевых ошибок, роста потребления ресурсов процессами, ресурсными группами и т.д.
  Собираются такие данные:
    - ps axuww
    - /sbin/ifconfig
    - netstat -s
    - динамические SQL-запросы:
      - gp_toolkit.gp_resgroup_status
      - gp_toolkit.gp_resgroup_status_per_host
      - pg_locks
      - pg_stat_activity

Номер снимка (1-й или 2-й) будет записан вначале файла, например:
1.ps_axuww_2025-01-01_08-00-00.csv.gz

3.2. Сбор статической информации состоит из сбора:
  - статические SQL-запросы:
    - gp_server_version
    - postmaster_uptime
    - postmaster_stat
    - gp_resgroup_config
    - pg_database
    - pg_db_role_setting
    - gp_segment_configuration
    - gp_configuration_history
  - логи сервисных утилит ADB и analyzedb:
    - adb_collected_info
    - gpAdminLogs
    - operation_log
    - db_analyze
  - различные конфиг-файлы и вывод утилит ОС
    - os-release, os-version
    - /etc/security/limits.conf
    - /etc/sysctl.conf
    - sysctl -a
    - netstat -rn
    - netstat -i
    - uname -a
    - dmesg -T
    - last -adFwx
    - hostnamectl
    - pg_controldata
    - init_config.conf
    - /home/gpadmin/arenadata_configs/init_config.conf
    - stat postmaster.pid
  - startup.log
  - sar-файлы
  - postgresql.conf
  - Проверка проходимости пакетов с MTU 9000:
    - test_ping_to_master.log.gz
    - test_ping_from_master.log.gz

3.3. с помощью опции -pxf задаётся дополнительный сбор PXF:
    - конфигураций PXF - pxf_conf_<TIMESTAMP>.tar.gz
    - лог-файлов PXF   - pxf_logs_<TIMESTAMP>.tar.gz

3.4. с помощью опции -gpperfmon задаётся дополнительный сбор из исторических таблиц базы данных gpperfmon:
    - gpperfmon.database_history.csv.gz
    - gpperfmon.diskspace_history.csv.gz
    - gpperfmon.log_alert_history.csv.gz
    - gpperfmon.network_interface_history.csv.gz
    - gpperfmon.queries_history.csv.gz
    - gpperfmon.segment_history.csv.gz
    - gpperfmon.socket_history.csv.gz
    - gpperfmon.system_history.csv.gz

3.5. с помощью опции -adbmon задаётся дополнительный сбор из таблиц схемы adbmon:
    - t_audit_gp_resgroup_status.csv.gz
    - t_audit_gp_resgroup_status_per_seg.csv.gz
    - t_audit_locks_usage.csv.gz
    - t_audit_mem_usage.csv.gz
    - t_audit_pg_stat_activity.csv.gz
    - t_audit_top.csv.gz

3.6. Сбор динамической информации 2-й снимок - это повторный сбор информации, указанной в пункте 3.1.
Номер снимка будет записан вначале файла, например:
2.ps_axuww_2025-01-01_08-10-00.csv.gz

Диагностические файлы собираются на мастер-ноду в рабочую директорию указанную параметром -dir.
После сбора файлов утилита adbmt формирует оконечный tar.gz.
Имя оконечного tar.gz файла состоит из имени утилиты adbmt и времени запуска утилиты.
Имя файла будет отображено в стандартном выводе и в лог-файле утилиты adbmt.
Например:
/tmp/adbmt_2025-01-01_08-00-00.tar.gz


*****************************************************
ПРИМЕРЫ КОМАНД:
*****************************************************

# Сбор журналов сообщений СУБД с мастер-ноды:
bash /tmp/adbmt/adbmt.sh gp_log_collector -gpseg -1 -start 2015-11-25_09:00 -end 2015-11-25_18:00

# Сбор журналов сообщений СУБД с mirror-сегмента №2:
bash /tmp/adbmt/adbmt.sh gp_log_collector -gpseg m2 -start 2015-11-25_09:00 -end 2015-11-25_18:00

# сбор диагностической информации (без PXF, gpperfmon, adbmon):
bash /tmp/adbmt/adbmt.sh gp_log_collector

# сбор диагностической информации с PXF
bash /tmp/adbmt/adbmt.sh gp_log_collector -pxf

# сбор диагностической информации с историей из БД gpperfmon:
bash /tmp/adbmt/adbmt.sh gp_log_collector -gpperfmon -start 2025-03-19_18:00 -end 2025-03-19_19:00

# сбор диагностической информации с историей из gpperfmon и adbmon:
bash /tmp/adbmt/adbmt.sh gp_log_collector -gpperfmon -adbmon -db dwh -start 2025-03-19_18:00 -end 2025-03-19_19:00

# сбор диагностической информации с таблицей t_audit_top:
bash /tmp/adbmt/adbmt.sh gp_log_collector -t_audit_top -db dwh -start 2025-03-19_18:00 -end 2025-03-19_19:00

